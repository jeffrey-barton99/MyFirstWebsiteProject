Submission

Idea 1

A website that allows a user to catalog comics/manga read sorted by genre, title, year, artist/author.

Idea 2

A website that allows a user to catalog and track Anime series/movies seen sorted by genre, title, year, artist/author.

Idea 3

A website that allows a user to catalog collectible figurines collected sorted by character name, character stats(ie age, ht, wt, personality, job), anime/manga seen in, and year aired.