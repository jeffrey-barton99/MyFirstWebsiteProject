Fillable Form:
-data entered into the webform
--web form contents:
---Manga/Anime title
---Author(s) (poss null)
---Artist or Mangaka
---Date published
---Date read/watched
---Category (Manga/Anime)
---(stretch goal) user uploaded coverart

-User Info (profile):
--Name
--password
--18 or older y/n
--Otaku y/n
--favorite anime/manga
--Other hobbies

Date account created
-date created
-date entered first complete form

the web pages w/content
-Front Page aka login page
--image
--links:
---About Us 
---New User (account creation)
---Chat with us (discord link)
---
-Home page
--


