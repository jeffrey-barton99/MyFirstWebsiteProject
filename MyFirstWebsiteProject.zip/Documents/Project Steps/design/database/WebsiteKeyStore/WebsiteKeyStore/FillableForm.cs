﻿namespace WebsiteKeyStore
{
    class FillableForm
    {
        public string Id { get; set; }
        
        public string FormData { get; set; }
        public string UserInfo { get; set; }
    }


}
