﻿namespace WebsiteKeyStore
{
    class UserInfo
    {
    public string Id { get; set; }

    public string userName { get; set; }
    public int age { get; set; }
    public string otakuStatus { get; set; }
    public string otherHobbies { get; set; }
    
    }


}
