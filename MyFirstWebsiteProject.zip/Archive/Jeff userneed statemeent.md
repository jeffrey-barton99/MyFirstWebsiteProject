Overview
The user would like a website that would allow have a system in place for cataloging comics/manga read by the user sorted by genre, title, year, artist/author/mangaka and then have a  allow users to interact with other users sharing comments, fanpics, fan fiction.  Ideally an open forum promoting interaction between the fanbase.
Scope of Work
Below are the top-level goals of this project with goal breakdown. Detailed goal breakdowns shall be
presented on a task by task basis as part of a standard project management methodology.
Top-Level Goals
• Specify content that will be entered into the fillable form portion of the site.
•	Specify what content can be shared.
• Specify types of interaction between users.
• Specify means of interaction between users (Discord chat).
• Specify rules for interaction and implementing ban if necessary.
• Define method for implimentation
