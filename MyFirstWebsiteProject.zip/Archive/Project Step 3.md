Since I mistakenly did this part in proj step 2, I'll try and do Step 2
actual here.

The user wants a website where they can go to keep track of comics/manga
they have read along with the details of the read material ie what the title was, when it was writen, and by whom. They would also like to interact with others that are interested in the same things in a web space that encourages sharing ideas and comments with other fans.   

Below is back to the Dev perspective
-Nice to have: Storage for each user to upload .jpg of fan drawn artwork


