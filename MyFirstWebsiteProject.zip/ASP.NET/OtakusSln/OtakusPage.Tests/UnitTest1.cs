using System;
using Xunit;

namespace OtakusPage.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
