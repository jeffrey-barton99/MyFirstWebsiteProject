# Headline 1
## Headline 2
### Headline 3
Paragraph 1 of text.

Next Paragraph.

## Headline lower down
Emphasis *is* **fun** ~strike through~.
`Console.WriteLine("Test");`
everythig inside a "``" is rendered as code

[A link to google](http://www.google.com)
when adding links, the thing it is goes inside [], and the link ()

Lists

1. This is first
2. This is second
3. This is third

- an item
- another item
- a third item

| Header | Second header|
|-|-|         (putting a line after a header)
| tag | Data |
| tag2 | data2 |
